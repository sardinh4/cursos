package school.sptech.provider;

import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.ArgumentsProvider;

import java.util.stream.Stream;

public class CalcularLucroTotalProvider implements ArgumentsProvider {

    @Override
    public Stream<? extends Arguments> provideArguments(ExtensionContext extensionContext) throws Exception {
        return Stream.of(
                Arguments.of(new Integer[]{1, 2, 3, 4}, new Boolean[]{false, false, false, false}, 15.0),
                Arguments.of(new Integer[]{1, 2, 3, 4}, new Boolean[]{true, true, true, true}, 7.5),
                Arguments.of(new Integer[]{2, 2, 3, 3}, new Boolean[]{false, true, false, true}, 11.25),
                Arguments.of(new Integer[]{4, 4, 1, 1}, new Boolean[]{false, false, true, true}, 12.0),
                Arguments.of(new Integer[]{3, 3, 3, 3}, new Boolean[]{true, true, true, true}, 8.0),
                Arguments.of(new Integer[]{}, new Boolean[]{}, 0.0),
                Arguments.of(new Integer[]{5, 6, 7}, new Boolean[]{false, false, false}, 0.0),
                Arguments.of(new Integer[]{1, 1, 1, 1}, new Boolean[]{false, false, false, false}, 12.0),
                Arguments.of(new Integer[]{2, 2, 2, 2}, new Boolean[]{true, true, true, true}, 7.0),
                Arguments.of(new Integer[]{3, 3, 3}, new Boolean[]{false, false, false}, 12.0),
                Arguments.of(new Integer[]{4, 4}, new Boolean[]{true, true}, 4.5),
                Arguments.of(new Integer[]{1, 3, 1, 3}, new Boolean[]{false, true, true, false}, 10.5),
                Arguments.of(new Integer[]{2, 4, 2, 4}, new Boolean[]{true, false, true, false}, 12.5),
                Arguments.of(new Integer[]{3, 1, 3, 1}, new Boolean[]{false, false, false, false}, 14.0),
                Arguments.of(new Integer[]{4, 3, 2, 1}, new Boolean[]{false, true, false, true}, 11.5),
                Arguments.of(new Integer[]{1, 2, 3, 4}, new Boolean[]{false, true, false, true}, 11.0)
        );
    }
}
