package school.sptech;

public class Cinema {

    Boolean validarSala(Integer sala){
        return sala <= 4 && sala >= 1;
    };

    Double calcularValorIngresso(Integer sala, Boolean meiaEntrada){

        if (validarSala(sala)) {

            if (meiaEntrada) {
                return (30.00 + (5.00 * (sala - 1))) / 2;
            }

            return 30.00 + (5.00 * (sala - 1));
        };

        return 0.0;


    };

    Double calcularLucroTotal(Integer[] salas, Boolean[] estudantes){

        Double somatoria = 0.0;

        for (Integer i = 0; i < salas.length; i++){
            somatoria += calcularValorIngresso(salas[i], estudantes[i]);
        }

        return somatoria * 0.1;
    };

    String calcularSeloTomatometro(Boolean[] reviews){

        Double fresh = 0.0;

        for (Integer i = 0; i < reviews.length; i++){
             if (reviews[i]){
                 fresh++;
             };
        };

        if (fresh/reviews.length*100 >= 60.00){
            return "fresh";
        };

        return "rotten";
    };



}